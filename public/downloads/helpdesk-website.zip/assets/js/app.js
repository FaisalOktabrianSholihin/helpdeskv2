
/**
 * Dua Tujuh Helpdesk — application core
 * Page markup is intentionally split into /pages/*.html.
 */
function initLoginFlow() {
  const toggle = document.getElementById('toggle-pass');
  const form = document.getElementById('login-form');
  if (!toggle || !form || form.dataset.initialized === '1') return;
  form.dataset.initialized = '1';

  toggle.addEventListener('click', () => {
    const pw = document.getElementById('password');
    const icon = document.querySelector('#toggle-pass svg');
    if (pw.type === 'password') { pw.type = 'text'; icon?.setAttribute('data-lucide', 'eye-off'); }
    else { pw.type = 'password'; icon?.setAttribute('data-lucide', 'eye'); }
    if (window.lucide) lucide.createIcons();
  });

  form.addEventListener('submit', async function (e) {
    e.preventDefault();
    const btn = document.getElementById('login-btn');
    const txt = document.getElementById('login-btn-text');
    const spin = document.getElementById('login-spinner');
    const error = document.getElementById('login-error');
    const email = document.getElementById('email')?.value.trim().toLowerCase();
    const password = document.getElementById('password')?.value;
    if (error) error.textContent = '';
    if (!email || !password) return;

    btn.disabled = true; txt.textContent = 'Memproses...'; spin.style.display = 'block';
    if (window.lucide) lucide.createIcons();

    try {
      await window.__helpdeskReady;
      const result = window.__helpdeskLogin?.(email, password);
      if (!result?.ok) {
        if (error) error.textContent = result?.message || 'Email atau password tidak sesuai.';
        btn.disabled = false; txt.textContent = 'Masuk'; spin.style.display = 'none';
        if (window.lucide) lucide.createIcons();
        return;
      }

      const loginScreen = document.getElementById('login-screen');
      loginScreen.classList.add('success');
      document.body.classList.add('login-success');
      const burst = document.createElement('div');
      burst.className = 'login-burst';
      burst.innerHTML = Array.from({length: 18}, (_, i) => `<i style="--i:${i}"></i>`).join('');
      loginScreen.appendChild(burst);
      if (typeof window.__helpdeskShowPage === 'function') window.__helpdeskShowPage('dashboard');

      setTimeout(() => {
        loginScreen.classList.add('hide');
        document.getElementById('app').classList.add('show');
        window.__helpdeskRefreshIdentity?.();
        setTimeout(() => window.__helpdeskToast?.(`Login berhasil. Selamat datang, ${result.user.nama}!`, 'sparkles'), 250);
      }, 650);
    } catch (err) {
      console.error(err);
      if (error) error.textContent = 'Aplikasi belum siap. Silakan coba lagi.';
      btn.disabled = false; txt.textContent = 'Masuk'; spin.style.display = 'none';
      if (window.lucide) lucide.createIcons();
    }
  });
}

async function bootHelpdesk() {
  const pageLoader = document.getElementById('page-loader');
  const content = document.getElementById('content');
  const pageFiles = ['dashboard','tiket-list','tiket-detail','cetak-tiket','divisi','karyawan','analitik','setting','roles','users'];

  pageLoader?.classList.add('show');
  try {
    const results = await Promise.all(pageFiles.map(async name => {
      const response = await fetch(`pages/${name}.html`, { cache: 'no-store' });
      if (!response.ok) throw new Error(`Gagal memuat halaman ${name}`);
      return response.text();
    }));
    content.insertAdjacentHTML('beforeend', results.join('\n'));
  } catch (error) {
    console.error(error);
    content.innerHTML = `
      <div class="card" style="margin:32px;padding:32px;text-align:center">
        <div style="font-size:42px;margin-bottom:12px">⚠️</div>
        <h2 style="margin:0 0 8px">Halaman belum dapat dimuat</h2>
        <p style="color:var(--text-mute);margin:0 0 18px">
          Jalankan project melalui Live Server / localhost agar file menu dapat dimuat.
        </p>
        <button class="btn btn-blue" onclick="location.reload()">Muat Ulang</button>
      </div>`;
    pageLoader?.classList.remove('show');
    return;
  }

  pageLoader?.classList.remove('show');

    lucide.createIcons();
    if (document.body.classList.contains('login-success')) {
      showPage('dashboard');
    }

    /* ============ STATE ============ */
    // User sesi harus dideklarasikan sebelum dipakai oleh state role/user.
    // Versi sebelumnya mereferensikan currentUser sebelum deklarasi sehingga
    // bootHelpdesk gagal dan login selalu menganggap kredensial tidak valid.
    let currentUser = null;
    try {
      currentUser = JSON.parse(localStorage.getItem('helpdesk_current_user') || 'null');
    } catch (e) {
      localStorage.removeItem('helpdesk_current_user');
      currentUser = null;
    }

    let ticketSeq = 890;
    let tickets = [
      { id: '#887', judul: 'Komputer tidak bisa menyala', deskripsi: 'Komputer tidak bisa menyala sejak pagi ini, sudah dicoba beberapa cara namun belum berhasil.', kontak: 'Bagus Tantowi', agen: 'Muhammad Andre', status: 'proses', prioritas: 'rendah', tipe: 'Incident', sumber: 'Telepon', telepon: '0813-2211-4477', dibuat: '11 Feb 2025 09:23', updated: '11 Feb 2025 09:23' },
      { id: '#886', judul: 'Akses email tidak bermasalah', deskripsi: 'Karyawan melaporkan tidak bisa login ke akun email kantor.', kontak: 'Sahrindra', agen: 'Sahrindra', status: 'menunggu', prioritas: 'sedang', tipe: 'Problem', sumber: 'Email', telepon: '0813-5566-7788', dibuat: '10 Feb 2025 14:11', updated: '10 Feb 2025 14:11' },
      { id: '#885', judul: 'Request perangkat komputer', deskripsi: 'Tolong buatkan rekomendasi perangkat komputer untuk kantor baru, terima kasih.', kontak: 'Bagus Tantowi', agen: 'Muhammad Andre', status: 'menunggu', prioritas: 'rendah', tipe: 'Feature Request', sumber: 'Telepon', telepon: '0813-1234-5678', dibuat: '11 Feb 2025 09:23', updated: '11 Feb 2025 13:56' },
      { id: '#884', judul: 'Printer tidak bisa print', deskripsi: 'Printer di ruang HR tidak merespon perintah cetak dari komputer manapun.', kontak: 'Andre Sahrindra', agen: 'Bagus Tantowi', status: 'selesai', prioritas: 'tinggi', tipe: 'Incident', sumber: 'Chat', telepon: '0813-9988-1122', dibuat: '08 Feb 2025 11:43', updated: '09 Feb 2025 10:00' },
      { id: '#883', judul: 'Instalasi aplikasi', deskripsi: 'Membutuhkan instalasi aplikasi akuntansi baru pada 3 unit komputer divisi Finance.', kontak: 'Sahrindra', agen: 'Sahrindra', status: 'proses', prioritas: 'sedang', tipe: 'Request', sumber: 'Web', telepon: '0813-4455-2233', dibuat: '07 Feb 2025 16:20', updated: '07 Feb 2025 16:20' },
      { id: '#882', judul: 'Request perangkat komputer', deskripsi: 'Divisi Marketing membutuhkan 2 unit laptop baru untuk karyawan baru.', kontak: 'Bagus Tantowi', agen: 'Muhammad Andre', status: 'baru', prioritas: 'sedang', tipe: 'Feature Request', sumber: 'Email', telepon: '0813-1234-5678', dibuat: '07 Feb 2025 15:08', updated: '07 Feb 2025 15:08' },
      { id: '#881', judul: 'Jaringan internet lambat', deskripsi: 'Koneksi internet di lantai 2 sangat lambat sejak kemarin siang.', kontak: 'Devi Lestari', agen: 'Bagus Tantowi', status: 'menunggu', prioritas: 'tinggi', tipe: 'Incident', sumber: 'Telepon', telepon: '0812-4444-5555', dibuat: '06 Feb 2025 10:02', updated: '06 Feb 2025 10:02' },
      { id: '#880', judul: 'Update sistem aplikasi', deskripsi: 'Perlu update sistem aplikasi HR ke versi terbaru untuk seluruh user.', kontak: 'Rudi Hermawan', agen: 'Sahrindra', status: 'selesai', prioritas: 'rendah', tipe: 'Request', sumber: 'Web', telepon: '0813-3333-4444', dibuat: '05 Feb 2025 08:47', updated: '06 Feb 2025 09:10' },
    ];

    let divisiSeq = 6;
    let divisiList = [
      { id: 1, nama: 'IT', desc: 'Information Technology' },
      { id: 2, nama: 'HRGA', desc: 'Human Resources & General Affair' },
      { id: 3, nama: 'Finance', desc: 'Finance & Accounting' },
      { id: 4, nama: 'Marketing', desc: 'Marketing & Communication' },
      { id: 5, nama: 'Operasional', desc: 'Operasional' },
    ];

    let karyawanSeq = 6;
    let karyawanList = [
      { id: 1, nama: 'Muhammad Andre Sahrindra', email: 'andre@mitratani27.co.id', divisiId: 1, tlp: '0813-3456-7890' },
      { id: 2, nama: 'Bagus Tantowi', email: 'bagus@mitratani27.co.id', divisiId: 1, tlp: '0813-1111-2222' },
      { id: 3, nama: 'Siti Aminah', email: 'siti@mitratani27.co.id', divisiId: 2, tlp: '0812-2222-3333' },
      { id: 4, nama: 'Rudi Hermawan', email: 'rudi@mitratani27.co.id', divisiId: 3, tlp: '0813-3333-4444' },
      { id: 5, nama: 'Devi Lestari', email: 'devi@mitratani27.co.id', divisiId: 4, tlp: '0812-4444-5555' },
    ];

    /* ============ GRANULAR PERMISSIONS ============
       Format permission: resource.action
       Contoh: karyawan.view, karyawan.create, karyawan.edit, karyawan.delete
    ============ */
    const permissionCatalog = [
      { resource:'dashboard', label:'Dashboard', actions:[['view','Lihat']] },
      { resource:'tiket', label:'Tiket', actions:[['view','Lihat'],['create','Buat'],['edit','Edit'],['delete','Hapus'],['reply','Balas'],['close','Tutup'],['print','Cetak']] },
      { resource:'divisi', label:'Divisi', actions:[['view','Lihat'],['create','Tambah'],['edit','Edit'],['delete','Hapus']] },
      { resource:'karyawan', label:'Karyawan', actions:[['view','Lihat'],['create','Tambah'],['edit','Edit'],['delete','Hapus']] },
      { resource:'analitik', label:'Analitik', actions:[['view','Lihat']] },
      { resource:'users', label:'Akun User', actions:[['view','Lihat'],['create','Tambah'],['edit','Edit'],['delete','Hapus']] },
      { resource:'setting', label:'Setting', actions:[['view','Lihat'],['edit','Edit']] },
      { resource:'roles', label:'Roles', actions:[['view','Lihat'],['create','Tambah'],['edit','Edit'],['delete','Hapus'],['permissions','Atur Hak Akses']] },
    ];
    const menuPermissions = permissionCatalog.map(p => [p.resource, p.label]);
    const allPermissionKeys = permissionCatalog.flatMap(p => p.actions.map(a => `${p.resource}.${a[0]}`));
    /* Struktur ini mengikuti persis urutan & pengelompokan menu di sidebar
       (label "MENU" / "LAINNYA", dan submenu "Kontak" berisi Divisi + Karyawan),
       supaya halaman Roles & Hak Akses terasa seperti "peta" dari sidebar. */
    const menuSections = [
      { label: 'MENU', entries: [
          { resource: 'dashboard' },
          { resource: 'tiket' },
          { group: 'Kontak', resources: ['divisi', 'karyawan'] },
          { resource: 'analitik' },
          { resource: 'users' },
        ] },
      { label: 'LAINNYA', entries: [
          { resource: 'setting' },
          { resource: 'roles' },
        ] },
    ];
    function permissionGroupHtml(resource, existingPerms, attr) {
      const group = permissionCatalog.find(p => p.resource === resource);
      if (!group) return '';
      return `<div class="permission-group"><div class="permission-group-head"><strong>${group.label}</strong><button type="button" class="link-btn" data-${attr}-all="${group.resource}">Pilih semua</button></div><div class="permission-actions">${group.actions.map(([action, label]) => { const key = `${group.resource}.${action}`; return `<label class="permission-action"><input type="checkbox" data-${attr}="${key}" ${existingPerms.includes(key) ? 'checked' : ''}><span>${label}</span><code>${key}</code></label>`; }).join('')}</div></div>`;
    }
    /* attr: 'perm' (modal Atur Hak Akses) atau 'newperm' (form Tambah/Edit Role) */
    function renderPermissionBuilder(existingPerms, attr) {
      return menuSections.map(section => {
        const body = section.entries.map(entry => {
          if (entry.group) {
            const inner = entry.resources.map(r => permissionGroupHtml(r, existingPerms, attr)).join('');
            return `<div class="permission-subsection"><div class="permission-subsection-label">${entry.group}</div>${inner}</div>`;
          }
          return permissionGroupHtml(entry.resource, existingPerms, attr);
        }).join('');
        return `<div class="permission-section"><div class="permission-section-label">${section.label}</div>${body}</div>`;
      }).join('');
    }
    const oldToNewPermission = {
      dashboard:'dashboard.view','tiket-list':'tiket.view','divisi':'divisi.view','karyawan':'karyawan.view',
      analitik:'analitik.view',users:'users.view',setting:'setting.view',roles:'roles.view'
    };
    function normalizePermissions(list){
      const out=[];
      (Array.isArray(list)?list:[]).forEach(key=>{
        const mapped=oldToNewPermission[key] || key;
        if(allPermissionKeys.includes(mapped)) out.push(mapped);
      });
      return [...new Set(out)];
    }
    const defaultSuperPermissions = [...allPermissionKeys];
    let roleSeq = 6;
    let rolesList = JSON.parse(localStorage.getItem('helpdesk_roles') || 'null') || [
      { id: 1, nama: 'Superadmin', permissions: defaultSuperPermissions, jml: 1 },
      { id: 2, nama: 'Admin IT', permissions: ['dashboard.view','tiket.view','tiket.create','tiket.edit','tiket.reply','tiket.close','tiket.print','divisi.view','divisi.create','divisi.edit','karyawan.view','karyawan.create','karyawan.edit','analitik.view','users.view','users.create','users.edit'], jml: 1 },
      { id: 3, nama: 'Admin HRGA', permissions: ['dashboard.view','tiket.view','tiket.create','tiket.edit','tiket.reply','tiket.print','analitik.view'], jml: 1 },
      { id: 4, nama: 'Agent', permissions: ['dashboard.view','tiket.view','tiket.reply','tiket.close','tiket.print','analitik.view'], jml: 1 },
      { id: 5, nama: 'User', permissions: ['dashboard.view','tiket.view','tiket.create','tiket.reply'], jml: 0 },
    ];
    const demoUsers = [
      { id:1, nama:'Super Administrator', email:'superadmin@mitratani27.co.id', password:'password', roleId:1, divisiId:null, active:true },
      { id:2, nama:'Muhammad Andre Sahrindra', email:'andre@mitratani27.co.id', password:'password', roleId:2, divisiId:1, active:true },
      { id:3, nama:'Admin HRGA', email:'admin.hrga@mitratani27.co.id', password:'password', roleId:3, divisiId:2, active:true },
      { id:4, nama:'Agent Helpdesk', email:'agent@mitratani27.co.id', password:'password', roleId:4, divisiId:1, active:true },
    ];
    let usersList;
    try {
      const storedUsers = JSON.parse(localStorage.getItem('helpdesk_users') || 'null');
      usersList = Array.isArray(storedUsers) && storedUsers.length ? storedUsers : demoUsers.map(u => ({...u}));
      // Pastikan akun demo tetap tersedia pada instalasi/versi lama.
      demoUsers.forEach(demo => {
        const exists = usersList.some(u => String(u.email || '').toLowerCase() === demo.email.toLowerCase());
        if (!exists) usersList.push({...demo});
      });
    } catch (e) {
      localStorage.removeItem('helpdesk_users');
      usersList = demoUsers.map(u => ({...u}));
    }
    let userSeq = Math.max(5, ...usersList.map(u=>Number(u.id)||0), 4) + 1;
    rolesList.forEach(r => {
      r.permissions = normalizePermissions(r.permissions);
      if (!r.permissions.length) r.permissions = r.nama.toLowerCase().includes('admin') ? [...defaultSuperPermissions] : ['dashboard.view','tiket.view'];
    });
    // Migrasi role lama dari versi sebelumnya yang masih memakai nama menu saja.
    localStorage.setItem('helpdesk_roles', JSON.stringify(rolesList));
    if (currentUser && !usersList.some(u => u.id === currentUser.id)) currentUser = null;
    let settingsState = JSON.parse(localStorage.getItem('helpdesk_settings') || 'null') || {
      company:{name:'PT. Mitratani Dua Tujuh', email:'helpdesk@mitratani27.co.id', phone:'0331-xxxxxx', address:'Jember, Jawa Timur'},
      email:{host:'smtp.mitratani27.co.id', port:'587', sender:'helpdesk@mitratani27.co.id', enabled:true},
      categories:['Incident','Request','Problem','Feature Request'],
      statuses:['Baru','Menunggu','Proses','Selesai'],
      backup:{last:'Belum pernah', frequency:'Harian'},
      general:{timezone:'Asia/Jakarta', language:'Bahasa Indonesia', autoRefresh:true}
    };
    const notifications = [
      {id:1, icon:'ticket', title:'Tiket #887 membutuhkan perhatian', text:'Komputer tidak bisa menyala', time:'5 menit lalu', unread:true},
      {id:2, icon:'message-circle', title:'Balasan baru diterima', text:'Sahrindra membalas tiket #886', time:'25 menit lalu', unread:true},
      {id:3, icon:'circle-check', title:'Tiket #884 selesai', text:'Printer HR sudah ditangani', time:'1 jam lalu', unread:false},
    ];

    let currentTicketId = null;

    const statusBadge = { baru: 'b-baru', menunggu: 'b-menunggu', proses: 'b-proses', selesai: 'b-selesai' };
    const statusLabel = { baru: 'Baru', menunggu: 'Menunggu', proses: 'Proses', selesai: 'Selesai' };
    const prioBadge = { rendah: 'b-rendah', sedang: 'b-sedang', tinggi: 'b-tinggi' };
    const prioLabel = { rendah: 'Rendah', sedang: 'Sedang', tinggi: 'Tinggi' };

    function esc(s) { const d = document.createElement('div'); d.textContent = s == null ? '' : s; return d.innerHTML; }
    function initials(name) { return (name || '?').split(' ').slice(0, 2).map(s => s[0]).join('').toUpperCase(); }
    function nowStr() {
      const d = new Date();
      const bulan = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
      const pad = n => String(n).padStart(2, '0');
      return `${pad(d.getDate())} ${bulan[d.getMonth()]} ${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
    }
    function divisiName(id) { const d = divisiList.find(x => x.id === id); return d ? d.nama : '—'; }

    /* ============ RENDER: TICKETS ============ */
    function ticketRow(t, withActions) {
      return `<tr class="clickable" data-open="${t.id}">
    <td class="cell-id">${esc(t.id)}</td>
    <td class="cell-strong">${esc(t.judul)}</td>
    <td>${esc(t.agen)}</td>
    <td><span class="badge ${statusBadge[t.status]}"><span class="dot"></span>${statusLabel[t.status]}</span></td>
    <td><span class="badge ${prioBadge[t.prioritas]}">${prioLabel[t.prioritas]}</span></td>
    <td style="color:var(--text-mute); font-weight:600;">${esc(t.dibuat)}</td>
    ${withActions ? `<td><div class="row-actions">
      <button class="icon-action ia-edit" data-edit-ticket="${t.id}"><svg class="icon" style="width:14px;height:14px;" data-lucide="pencil"></svg></button>
      <button class="icon-action ia-del" data-del-ticket="${t.id}"><svg class="icon" style="width:14px;height:14px;" data-lucide="trash-2"></svg></button>
    </div></td>` : ''}
  </tr>`;
    }
    function renderDashboard() {
      document.getElementById('dash-recent-body').innerHTML = tickets.slice(0, 5).map(t => ticketRow(t, false)).join('') || `<tr class="empty-row"><td colspan="6">Belum ada tiket</td></tr>`;
      const waiting = tickets.filter(t => t.status === 'menunggu').slice(0, 4);
      document.getElementById('dash-waiting-list').innerHTML = waiting.length ? waiting.map((t, i) => `
    ${i > 0 ? '<div class="divider"></div>' : ''}
    <div>
      <div style="display:flex; align-items:center; gap:8px; font-weight:800; font-size:13px;">${esc(t.id)} <span class="badge b-menunggu" style="padding:2px 8px; font-size:10px;">Menunggu</span></div>
      <div style="font-size:12.5px; color:var(--text-soft); margin-top:2px;">${esc(t.judul)}</div>
      <div class="cell-sub">${esc(t.kontak)}</div>
    </div>`).join('') : `<div style="color:var(--text-mute); font-size:13px; padding:8px 0;">Tidak ada tiket menunggu.</div>`;

      const counts = { baru: 0, menunggu: 0, proses: 0, selesai: 0 };
      tickets.forEach(t => counts[t.status]++);
      const total = tickets.length || 1;
      const legendColors = { baru: 'var(--violet)', menunggu: '#B7791F', proses: 'var(--amber)', selesai: 'var(--teal)' };
      document.getElementById('status-legend').innerHTML = Object.keys(counts).map(k => `
    <div class="legend-row"><span class="legend-left"><span class="legend-sw" style="background:${legendColors[k]};"></span>${statusLabel[k]}</span><span class="legend-val">${counts[k]} (${Math.round(counts[k] / total * 100)}%)</span></div>
  `).join('');

      document.getElementById('kpi-menunggu').dataset.target = counts.menunggu;
      document.getElementById('kpi-selesai').dataset.target = counts.selesai;
      document.getElementById('kpi-terbuka').dataset.target = counts.baru;
      document.getElementById('kpi-total').dataset.target = tickets.length;
      lucide.createIcons();
    }
    function renderTicketList() {
      const search = (document.getElementById('ticket-search').value || '').toLowerCase();
      const fStatus = document.getElementById('filter-status').value;
      const fPrio = document.getElementById('filter-prioritas').value;
      const fTipe = document.getElementById('filter-tipe').value;
      const filtered = tickets.filter(t => {
        if (search && !(t.judul.toLowerCase().includes(search) || t.id.toLowerCase().includes(search) || t.kontak.toLowerCase().includes(search))) return false;
        if (fStatus && t.status !== fStatus) return false;
        if (fPrio && t.prioritas !== fPrio) return false;
        if (fTipe && t.tipe !== fTipe) return false;
        return true;
      });
      document.getElementById('ticket-list-body').innerHTML = filtered.length ? filtered.map(t => ticketRow(t, true)).join('')
        : `<tr class="empty-row"><td colspan="7">Tidak ada tiket yang cocok dengan pencarian/filter.</td></tr>`;
      document.getElementById('ticket-count-label').textContent = `Menampilkan ${filtered.length} dari ${tickets.length} tiket`;
      lucide.createIcons();
    }

    function renderTicketDetail(id) {
      const t = tickets.find(x => x.id === id);
      if (!t) return;
      currentTicketId = id;
      document.getElementById('detail-id').textContent = t.id;
      document.getElementById('detail-status-badge').className = 'badge ' + statusBadge[t.status];
      document.getElementById('detail-status-badge').innerHTML = `<span class="dot"></span>${statusLabel[t.status]}`;
      document.getElementById('detail-keadaan').textContent = statusLabel[t.status];
      document.getElementById('detail-prioritas-badge').className = 'badge ' + prioBadge[t.prioritas];
      document.getElementById('detail-prioritas-badge').textContent = prioLabel[t.prioritas];
      document.getElementById('detail-sumber').textContent = t.sumber;
      document.getElementById('detail-tipe').textContent = t.tipe;
      document.getElementById('detail-agen').textContent = t.agen;
      document.getElementById('detail-kontak').textContent = t.kontak;
      document.getElementById('detail-kontak').classList.add('profile-link');
      document.getElementById('detail-kontak').setAttribute('data-profile-contact', t.kontak);
      document.getElementById('detail-kontak').style.cursor='pointer';
      document.getElementById('detail-kontak-initial').textContent = initials(t.kontak);
      document.getElementById('detail-meta').textContent = `oleh ${t.kontak} pada ${t.dibuat} via ${t.sumber}`;
      document.getElementById('detail-desc').textContent = t.deskripsi;
      document.getElementById('info-id').textContent = t.id;
      document.getElementById('info-dibuat').textContent = t.dibuat;
      document.getElementById('info-updated').textContent = t.updated;
      document.getElementById('info-status-badge').className = 'badge ' + statusBadge[t.status];
      document.getElementById('info-status-badge').textContent = statusLabel[t.status];
      document.getElementById('info-prioritas-badge').className = 'badge ' + prioBadge[t.prioritas];
      document.getElementById('info-prioritas-badge').textContent = prioLabel[t.prioritas];
      document.getElementById('info-tipe').textContent = t.tipe;
      document.getElementById('info-telepon').textContent = t.telepon;

      document.getElementById('paper-id').textContent = t.id;
      document.getElementById('paper-keadaan').textContent = statusLabel[t.status];
      document.getElementById('paper-prioritas').textContent = prioLabel[t.prioritas];
      document.getElementById('paper-sumber').textContent = t.sumber;
      document.getElementById('paper-tipe').textContent = t.tipe;
      document.getElementById('paper-agen').textContent = t.agen;
      document.getElementById('paper-meta').textContent = `oleh ${t.kontak} pada ${t.dibuat} via ${t.sumber}`;
      document.getElementById('paper-judul-label').textContent = t.judul;
      document.getElementById('paper-desc').textContent = t.deskripsi;

      const printNow = new Date();
      const printDate = `${printNow.getMonth() + 1}/${printNow.getDate()}/${String(printNow.getFullYear()).slice(-2)}, ${printNow.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}`;
      document.getElementById('paper-print-date').textContent = printDate;
      document.getElementById('paper-print-url').textContent = `m27.helpdesk.com/helpdesk/tickets/${String(t.id).replace('#','')}/print`;

      const commentMeta = document.getElementById('paper-comment-meta');
      const commentBody = document.getElementById('paper-comment-body');
      if (commentMeta && commentBody) {
        commentMeta.textContent = `oleh ${currentUser?.name || t.agen} pada ${t.updated} as Email keluar`;
        commentBody.innerHTML = `Hi ${esc(t.kontak)},<br><br>Setelah dilakukan pemeriksaan oleh bagian teknologi informasi, laporan tiket <strong>${esc(t.id)}</strong> mengenai <strong>${esc(t.judul.toLowerCase())}</strong> telah ditindaklanjuti. Demikian laporan yang dapat kami sampaikan, atas perhatiannya kami ucapkan terima kasih.`;
      }
    }

    /* ============ RENDER: DIVISI ============ */
    function renderDivisi() {
      document.getElementById('divisi-body').innerHTML = divisiList.length ? divisiList.map(d => {
        const jml = karyawanList.filter(k => k.divisiId === d.id).length;
        return `<tr>
      <td class="cell-strong">${esc(d.nama)}</td>
      <td style="color:var(--text-soft); white-space:normal;">${esc(d.desc)}</td>
      <td>${jml}</td>
      <td><div class="row-actions">
        <button class="icon-action ia-edit" data-edit-divisi="${d.id}"><svg class="icon" style="width:14px;height:14px;" data-lucide="pencil"></svg></button>
        <button class="icon-action ia-del" data-del-divisi="${d.id}"><svg class="icon" style="width:14px;height:14px;" data-lucide="trash-2"></svg></button>
      </div></td>
    </tr>`;
      }).join('') : `<tr class="empty-row"><td colspan="4">Belum ada divisi. Klik "Tambah Divisi" untuk membuat.</td></tr>`;
      lucide.createIcons();
      refreshDivisiSelects();
    }

    /* ============ RENDER: KARYAWAN ============ */
    function refreshDivisiSelects() {
      const opts = divisiList.map(d => `<option value="${d.id}">${esc(d.nama)}</option>`).join('');
      const filterSel = document.getElementById('karyawan-filter-divisi');
      const curVal = filterSel.value;
      filterSel.innerHTML = `<option value="">Semua Divisi</option>` + opts;
      filterSel.value = curVal;
    }
    function renderKaryawan() {
      const search = (document.getElementById('karyawan-search').value || '').toLowerCase();
      const fDivisi = document.getElementById('karyawan-filter-divisi').value;
      const filtered = karyawanList.filter(k => {
        if (search && !(k.nama.toLowerCase().includes(search) || k.email.toLowerCase().includes(search))) return false;
        if (fDivisi && String(k.divisiId) !== String(fDivisi)) return false;
        return true;
      });
      document.getElementById('karyawan-body').innerHTML = filtered.length ? filtered.map(k => `
    <tr>
      <td><div class="avatar-row"><div class="avatar-sm">${initials(k.nama)}</div><span class="cell-strong">${esc(k.nama)}</span></div></td>
      <td style="color:var(--text-soft);">${esc(k.email)}</td>
      <td><span class="badge b-baru">${esc(divisiName(k.divisiId))}</span></td>
      <td style="color:var(--text-soft);">${esc(k.tlp)}</td>
      <td><div class="row-actions">
        <button class="icon-action ia-edit" data-edit-karyawan="${k.id}"><svg class="icon" style="width:14px;height:14px;" data-lucide="pencil"></svg></button>
        <button class="icon-action ia-del" data-del-karyawan="${k.id}"><svg class="icon" style="width:14px;height:14px;" data-lucide="trash-2"></svg></button>
      </div></td>
    </tr>`).join('') : `<tr class="empty-row"><td colspan="5">Tidak ada karyawan yang cocok.</td></tr>`;
      lucide.createIcons();
    }

    /* ============ RENDER: ROLES ============ */
    function renderRoles() {
      rolesList.forEach(r => r.jml = usersList.filter(u => u.roleId === r.id).length);
      const body = document.getElementById('roles-body');
      if (!body) return;
      body.innerHTML = rolesList.length ? rolesList.map(r => `
    <tr>
      <td><div class="cell-strong">${esc(r.nama)}</div><div class="role-perm-summary">${new Set((r.permissions||[]).map(p=>p.split('.')[0])).size} resource diizinkan</div></td>
      <td>${r.jml} pengguna</td>
      <td><div class="row-actions">
        <button class="icon-action" data-perm-role="${r.id}" title="Atur hak akses"><svg class="icon" style="width:14px;height:14px;" data-lucide="key-round"></svg></button>
        <button class="icon-action ia-edit" data-edit-role="${r.id}"><svg class="icon" style="width:14px;height:14px;" data-lucide="pencil"></svg></button>
        <button class="icon-action ia-del" data-del-role="${r.id}"><svg class="icon" style="width:14px;height:14px;" data-lucide="trash-2"></svg></button>
      </div></td>
    </tr>`).join('') : `<tr class="empty-row"><td colspan="3">Belum ada role.</td></tr>`;
      lucide.createIcons();
    }

    function renderUsers() {
      const body = document.getElementById('users-body'); if (!body) return;
      body.innerHTML = usersList.map(u => {
        const role = rolesList.find(r=>r.id===u.roleId);
        return `<tr><td><div class="avatar-row"><div class="avatar-sm">${initials(u.nama)}</div><div><div class="cell-strong">${esc(u.nama)}</div><div class="role-perm-summary">${esc(u.email)}</div></div></div></td><td>${esc(role?.nama||'—')}</td><td>${esc(divisiName(u.divisiId))}</td><td><span class="badge ${u.active?'b-selesai':'b-rendah'}">${u.active?'Aktif':'Nonaktif'}</span></td><td><div class="row-actions"><button class="icon-action ia-edit" data-edit-user="${u.id}"><svg class="icon" style="width:14px;height:14px;" data-lucide="pencil"></svg></button><button class="icon-action ia-del" data-del-user="${u.id}"><svg class="icon" style="width:14px;height:14px;" data-lucide="trash-2"></svg></button></div></td></tr>`;
      }).join('');
      lucide.createIcons();
    }

    /* ============ SETTING GRID ============ */
    const settingItems = [
      { key:'company', icon:'building-2', title:'Profil Perusahaan', sub:'Kelola informasi perusahaan Anda' },
      { key:'email', icon:'mail-check', title:'Pengaturan Email', sub:'Konfigurasi email notifikasi' },
      { key:'categories', icon:'tags', title:'Kategori Tiket', sub:'Kelola kategori dan prioritas tiket' },
      { key:'statuses', icon:'radio', title:'Status Tiket', sub:'Kelola status dan alur tiket' },
      { key:'backup', icon:'database-backup', title:'Backup & Restore', sub:'Kelola backup data sistem' },
      { key:'general', icon:'sliders-horizontal', title:'Umum', sub:'Pengaturan umum sistem' },
    ];
    document.getElementById('setting-grid').innerHTML = settingItems.map(s => `
  <button class="setting-card" type="button" data-setting="${s.key}">
    <div class="setting-icon"><svg class="icon" data-lucide="${s.icon}"></svg></div>
    <div><div class="setting-text-title">${s.title}</div><div class="setting-text-sub">${s.sub}</div></div>
    <svg class="icon setting-chev" data-lucide="chevron-right"></svg>
  </button>`).join('');

    /* initial render */
    renderDashboard(); renderTicketList(); renderDivisi(); renderKaryawan(); renderRoles(); renderUsers();
    if (currentUser) refreshIdentity();
    lucide.createIcons();

    function persistAdminState() {
      localStorage.setItem('helpdesk_roles', JSON.stringify(rolesList));
      localStorage.setItem('helpdesk_users', JSON.stringify(usersList));
      localStorage.setItem('helpdesk_settings', JSON.stringify(settingsState));
    }
    function currentRole() { return rolesList.find(r => r.id === currentUser?.roleId) || rolesList[0]; }
    const pageResource = {dashboard:'dashboard','tiket-list':'tiket','tiket-detail':'tiket','cetak-tiket':'tiket',divisi:'divisi',karyawan:'karyawan',analitik:'analitik',users:'users',setting:'setting',roles:'roles'};
    function can(resource, action='view') {
      const perms = currentRole()?.permissions || [];
      return perms.includes(`${resource}.${action}`);
    }
    function canAccess(page) { return can(pageResource[page] || page, 'view'); }
    function requirePermission(resource, action='view', message='Anda tidak memiliki hak akses untuk tindakan ini.') {
      if (can(resource, action)) return true;
      showToast(message, 'shield-alert');
      return false;
    }
    function applyPermissions() {
      document.querySelectorAll('.nav-item[data-page]').forEach(n => { n.style.display = canAccess(n.dataset.page) ? '' : 'none'; });
      const sub = document.getElementById('kontak-sub');
      if (sub) sub.style.display = (canAccess('divisi') || canAccess('karyawan')) ? '' : 'none';
      document.querySelectorAll('[data-action-permission]').forEach(el => {
        const [resource, action] = el.dataset.actionPermission.split('.');
        el.style.display = can(resource, action) ? '' : 'none';
      });
    }
    function refreshIdentity() {
      if (!currentUser) return;
      const role = currentRole();
      const avatarText = initials(currentUser.nama);
      document.querySelectorAll('.sb-foot-name,.topbar-user-name').forEach(el => el.textContent = currentUser.nama);
      document.querySelectorAll('.sb-foot-role,.topbar-user-role').forEach(el => el.textContent = role?.nama || 'User');
      document.querySelectorAll('#sidebar .avatar, .topbar-user .avatar').forEach(el => el.textContent = avatarText);
      const welcome = document.querySelector('#page-dashboard h1');
      if (welcome) welcome.innerHTML = `Selamat datang kembali, ${esc(currentUser.nama)} 👋`;
      applyPermissions();
    }
    function loginUser(email, password) {
      const user = usersList.find(u => u.email.toLowerCase() === email.toLowerCase() && u.password === password && u.active);
      if (!user) return {ok:false, message:'Email/password salah atau akun sedang nonaktif.'};
      currentUser = {...user};
      localStorage.setItem('helpdesk_current_user', JSON.stringify(currentUser));
      refreshIdentity();
      return {ok:true,user};
    }
    function logout() {
      localStorage.removeItem('helpdesk_current_user');
      currentUser = null;
      document.getElementById('app')?.classList.remove('show');
      const login = document.getElementById('login-screen');
      login?.classList.remove('hide','success');
      document.body.classList.remove('login-success');
      const form = document.getElementById('login-form'); form?.reset();
      document.getElementById('email').value = 'superadmin@mitratani27.co.id';
      document.getElementById('password').value = 'password';
      document.getElementById('login-btn').disabled = false;
      document.getElementById('login-btn-text').textContent = 'Masuk';
      document.getElementById('login-spinner').style.display = 'none';
      document.getElementById('login-error').textContent = '';
      showToast('Anda telah logout', 'log-out');
    }
    function showNotificationPanel() {
      let panel = document.getElementById('notification-panel');
      if (!panel) return;
      panel.classList.toggle('show');
      if (panel.classList.contains('show')) {
        panel.innerHTML = `<div class="notif-head"><strong>Notifikasi</strong><button id="mark-notif-read" class="link-btn">Tandai dibaca</button></div><div class="notif-list">${notifications.map(n=>`<div class="notif-item ${n.unread?'unread':''}" data-notif="${n.id}"><div class="notif-icon"><svg class="icon" data-lucide="${n.icon}"></svg></div><div><strong>${esc(n.title)}</strong><p>${esc(n.text)}</p><small>${esc(n.time)}</small></div></div>`).join('')}</div>`;
        lucide.createIcons();
        document.getElementById('mark-notif-read')?.addEventListener('click',()=>{notifications.forEach(n=>n.unread=false); renderNotificationDot(); showNotificationPanel(); showToast('Semua notifikasi ditandai sudah dibaca','check');});
      }
    }
    function renderNotificationDot() { const dot=document.querySelector('.notif-dot'); if(dot) dot.style.display=notifications.some(n=>n.unread)?'block':'none'; }
    window.__helpdeskLogin = loginUser;
    window.__helpdeskLogout = logout;
    window.__helpdeskRefreshIdentity = refreshIdentity;
    window.__helpdeskToast = (msg, icon='check') => showToast(msg, icon);

    /* ============ NAVIGATION ============ */
    const titles = {
      'dashboard': 'Dashboard', 'tiket-list': 'Tiket', 'tiket-detail': 'Detail Tiket', 'cetak-tiket': 'Cetak Tiket',
      'divisi': 'Divisi', 'karyawan': 'Karyawan', 'analitik': 'Analitik', 'users': 'Akun User', 'setting': 'Setting', 'roles': 'Roles'
    };
    function showPage(id) {
      if (currentUser && !canAccess(id) && id !== 'tiket-detail' && id !== 'cetak-tiket') { showToast('Anda tidak memiliki akses ke menu ini', 'shield-alert'); return; }
      document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
      const target = document.getElementById('page-' + id);
      if (target) target.classList.add('active');
      document.getElementById('topbar-title').textContent = titles[id] || 'Dashboard';
      document.getElementById('content').scrollTo({ top: 0, behavior: 'smooth' });
      document.querySelectorAll('.nav-item[data-page]').forEach(n => n.classList.toggle('active', n.dataset.page === id));
      if (id === 'dashboard') { animateCounts(document.getElementById('page-dashboard')); renderCharts(); }
      if (id === 'analitik') { animateCounts(document.getElementById('page-analitik')); renderAnalyticsCharts(); }
      closeMobileSidebar();
    }
    window.__helpdeskShowPage = showPage;
    document.body.addEventListener('click', (e) => {
      const navEl = e.target.closest('[data-page]');
      if (navEl) { e.preventDefault(); showPage(navEl.dataset.page); return; }

      const settingBtn = e.target.closest('[data-setting]');
      if (settingBtn) { openSettingForm(settingBtn.dataset.setting); return; }
      const profileBtn = e.target.closest('[data-profile-contact]');
      if (profileBtn) { openContactProfile(profileBtn.dataset.profileContact); return; }
      const permBtn = e.target.closest('[data-perm-role]');
      if (permBtn) { if(requirePermission('roles','permissions','Anda tidak memiliki hak untuk mengatur permission role.')) openRolePermissions(Number(permBtn.dataset.permRole)); return; }
      const editU = e.target.closest('[data-edit-user]');
      if (editU) { if(requirePermission('users','edit','Anda tidak memiliki hak untuk mengedit akun.')) openUserForm(Number(editU.dataset.editUser)); return; }
      const delU = e.target.closest('[data-del-user]');
      if (delU) { if(requirePermission('users','delete','Anda tidak memiliki hak untuk menghapus akun.')) confirmDeleteUser(Number(delU.dataset.delUser)); return; }

      const row = e.target.closest('[data-open]');
      if (row && !e.target.closest('[data-edit-ticket],[data-del-ticket]')) { showPage('tiket-detail'); renderTicketDetail(row.dataset.open); return; }

      const editT = e.target.closest('[data-edit-ticket]');
      if (editT) { e.stopPropagation(); openTicketForm(editT.dataset.editTicket); return; }
      const delT = e.target.closest('[data-del-ticket]');
      if (delT) { e.stopPropagation(); confirmDeleteTicket(delT.dataset.delTicket); return; }

      const editD = e.target.closest('[data-edit-divisi]');
      if (editD) { if(requirePermission('divisi','edit','Anda tidak memiliki hak untuk mengedit divisi.')) openDivisiForm(Number(editD.dataset.editDivisi)); return; }
      const delD = e.target.closest('[data-del-divisi]');
      if (delD) { if(requirePermission('divisi','delete','Anda tidak memiliki hak untuk menghapus divisi.')) confirmDeleteDivisi(Number(delD.dataset.delDivisi)); return; }

      const editK = e.target.closest('[data-edit-karyawan]');
      if (editK) { if(requirePermission('karyawan','edit','Anda tidak memiliki hak untuk mengedit karyawan.')) openKaryawanForm(Number(editK.dataset.editKaryawan)); return; }
      const delK = e.target.closest('[data-del-karyawan]');
      if (delK) { if(requirePermission('karyawan','delete','Anda tidak memiliki hak untuk menghapus karyawan.')) confirmDeleteKaryawan(Number(delK.dataset.delKaryawan)); return; }

      const editR = e.target.closest('[data-edit-role]');
      if (editR) { if(requirePermission('roles','edit','Anda tidak memiliki hak untuk mengedit role.')) openRoleForm(Number(editR.dataset.editRole)); return; }
      const delR = e.target.closest('[data-del-role]');
      if (delR) { if(requirePermission('roles','delete','Anda tidak memiliki hak untuk menghapus role.')) confirmDeleteRole(Number(delR.dataset.delRole)); return; }
    });

    /* Kontak submenu */
    const kontakToggle = document.getElementById('kontak-toggle');
    const kontakSub = document.getElementById('kontak-sub');
    kontakToggle.addEventListener('click', () => {
      kontakToggle.classList.toggle('open');
      kontakSub.classList.toggle('open');
    });

    /* Sidebar mobile drawer */
    const sidebarEl = document.getElementById('sidebar');
    const overlayEl = document.getElementById('sidebar-overlay');
    function openMobileSidebar() { sidebarEl.classList.add('mobile-open'); overlayEl.classList.add('show'); }
    function closeMobileSidebar() { sidebarEl.classList.remove('mobile-open'); overlayEl.classList.remove('show'); }
    document.getElementById('sb-close-btn').addEventListener('click', closeMobileSidebar);
    overlayEl.addEventListener('click', closeMobileSidebar);
    document.getElementById('notification-btn')?.addEventListener('click', (e)=>{e.stopPropagation();showNotificationPanel();});
    document.getElementById('logout-btn')?.addEventListener('click', logout);
    document.getElementById('topbar-user')?.addEventListener('click', ()=>openCurrentUserProfile());
    document.addEventListener('click', e=>{ if(!e.target.closest('#notification-btn,#notification-panel')) document.getElementById('notification-panel')?.classList.remove('show'); });
    renderNotificationDot();

    /* Ticket filters */
    ['ticket-search', 'filter-status', 'filter-prioritas', 'filter-tipe'].forEach(id => {
      document.getElementById(id).addEventListener('input', renderTicketList);
      document.getElementById(id).addEventListener('change', renderTicketList);
    });
    document.getElementById('karyawan-search').addEventListener('input', renderKaryawan);
    document.getElementById('karyawan-filter-divisi').addEventListener('change', renderKaryawan);

    /* Buttons -> pages / toasts */
    document.getElementById('cetak-tiket-btn').addEventListener('click', () => { if(requirePermission('tiket','print','Anda tidak memiliki hak untuk mencetak tiket.')) showPage('cetak-tiket'); });
    document.getElementById('download-btn').addEventListener('click', () => window.print());
    document.getElementById('print-cancel-btn')?.addEventListener('click', () => showPage('tiket-detail'));
    document.getElementById('send-reply-btn').addEventListener('click', () => { if(!requirePermission('tiket','reply','Anda tidak memiliki hak untuk membalas tiket.')) return;
      const box = document.getElementById('reply-text');
      if (!box.value.trim()) { showToast('Tulis balasan terlebih dahulu', 'triangle-alert'); return; }
      const t = tickets.find(x => x.id === currentTicketId);
      const wrap = document.getElementById('detail-comments');
      const div = document.createElement('div');
      div.className = 'comment';
      div.innerHTML = `<div class="avatar-sm" style="width:30px;height:30px;font-size:12px;">MA</div>
    <div class="comment-body"><div class="comment-name">Muhammad Andre<span class="comment-time">${nowStr()} · Balasan baru</span></div>${esc(box.value)}</div>`;
      wrap.appendChild(div);
      if (t) { t.updated = nowStr(); renderTicketDetail(t.id); }
      box.value = '';
      showToast('Balasan berhasil dikirim', 'send');
    });
    document.getElementById('tutup-tiket-btn').addEventListener('click', () => { if(!requirePermission('tiket','close','Anda tidak memiliki hak untuk menutup tiket.')) return;
      const t = tickets.find(x => x.id === currentTicketId);
      if (!t) return;
      t.status = 'selesai'; t.updated = nowStr();
      renderTicketDetail(t.id); renderTicketList(); renderDashboard();
      showToast(`Tiket ${t.id} telah ditutup`, 'check');
    });
    document.getElementById('hapus-tiket-btn').addEventListener('click', () => { if(requirePermission('tiket','delete','Anda tidak memiliki hak untuk menghapus tiket.')) confirmDeleteTicket(currentTicketId, true); });
    document.getElementById('edit-tiket-btn').addEventListener('click', () => { if(requirePermission('tiket','edit','Anda tidak memiliki hak untuk mengedit tiket.')) openTicketForm(currentTicketId); });
    document.getElementById('new-ticket-btn').addEventListener('click', () => { if(requirePermission('tiket','create','Anda tidak memiliki hak untuk membuat tiket.')) openTicketForm(null); });
    document.getElementById('new-divisi-btn').addEventListener('click', () => { if(requirePermission('divisi','create','Anda tidak memiliki hak untuk menambah divisi.')) openDivisiForm(null); });
    document.getElementById('new-karyawan-btn').addEventListener('click', () => { if(requirePermission('karyawan','create','Anda tidak memiliki hak untuk menambah karyawan.')) openKaryawanForm(null); });
    document.getElementById('new-role-btn').addEventListener('click', () => { if(requirePermission('roles','create','Anda tidak memiliki hak untuk menambah role.')) openRoleForm(null); });
    document.getElementById('new-user-btn').addEventListener('click', () => { if(requirePermission('users','create','Anda tidak memiliki hak untuk menambah akun.')) openUserForm(null); });

    function showToast(text, icon) {
      const t = document.getElementById('toast');
      document.getElementById('toast-text').textContent = text;
      t.querySelector('.toast-ic').innerHTML = `<svg class="icon" style="width:14px;height:14px;color:#fff;" data-lucide="${icon || 'check'}"></svg>`;
      lucide.createIcons();
      t.classList.add('show');
      clearTimeout(window._toastTimer);
      window._toastTimer = setTimeout(() => t.classList.remove('show'), 2800);
    }
    window.__helpdeskToast = showToast;

    /* ============ MODAL ENGINE ============ */
    const modalOverlay = document.getElementById('modal-overlay');
    const modalBox = document.getElementById('modal-box');
    function openModal(title, bodyHTML, footHTML, small) {
      document.getElementById('modal-title').textContent = title;
      document.getElementById('modal-body').innerHTML = bodyHTML;
      document.getElementById('modal-foot').innerHTML = footHTML;
      modalBox.classList.toggle('modal-confirm', !!small);
      modalOverlay.classList.add('show');
      lucide.createIcons();
    }
    function closeModal() { modalOverlay.classList.remove('show'); }
    document.getElementById('modal-close-btn').addEventListener('click', closeModal);
    modalOverlay.addEventListener('click', (e) => { if (e.target === modalOverlay) closeModal(); });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeModal(); });

    /* ============ TICKET FORM ============ */
    function openTicketForm(id) {
      const editing = !!id;
      const t = editing ? tickets.find(x => x.id === id) : null;
      const body = `
    <div class="form-field"><label>Judul Tiket</label><input class="form-input" id="f-judul" value="${t ? esc(t.judul) : ''}" placeholder="Contoh: Printer tidak bisa print"></div>
    <div class="form-field"><label>Deskripsi</label><textarea class="form-textarea" id="f-desc" placeholder="Jelaskan detail kendala...">${t ? esc(t.deskripsi) : ''}</textarea></div>
    <div class="form-row-2">
      <div class="form-field"><label>Nama Kontak</label><input class="form-input" id="f-kontak" value="${t ? esc(t.kontak) : ''}" placeholder="Nama pelapor"></div>
      <div class="form-field"><label>No. Telepon</label><input class="form-input" id="f-telepon" value="${t ? esc(t.telepon) : ''}" placeholder="08xx-xxxx-xxxx"></div>
    </div>
    <div class="form-row-2">
      <div class="form-field"><label>Prioritas</label><div class="select-wrap-form"><select class="form-select" id="f-prioritas">
        ${['rendah', 'sedang', 'tinggi'].map(p => `<option value="${p}" ${t && t.prioritas === p ? 'selected' : ''}>${prioLabel[p]}</option>`).join('')}
      </select><svg class="icon" data-lucide="chevron-down"></svg></div></div>
      <div class="form-field"><label>Status</label><div class="select-wrap-form"><select class="form-select" id="f-status">
        ${['baru', 'menunggu', 'proses', 'selesai'].map(s => `<option value="${s}" ${t && t.status === s ? 'selected' : ''}>${statusLabel[s]}</option>`).join('')}
      </select><svg class="icon" data-lucide="chevron-down"></svg></div></div>
    </div>
    <div class="form-row-2">
      <div class="form-field"><label>Tipe</label><div class="select-wrap-form"><select class="form-select" id="f-tipe">
        ${['Incident', 'Request', 'Problem', 'Feature Request'].map(v => `<option value="${v}" ${t && t.tipe === v ? 'selected' : ''}>${v}</option>`).join('')}
      </select><svg class="icon" data-lucide="chevron-down"></svg></div></div>
      <div class="form-field"><label>Sumber</label><div class="select-wrap-form"><select class="form-select" id="f-sumber">
        ${['Telepon', 'Email', 'Chat', 'Web'].map(v => `<option value="${v}" ${t && t.sumber === v ? 'selected' : ''}>${v}</option>`).join('')}
      </select><svg class="icon" data-lucide="chevron-down"></svg></div></div>
    </div>
    <div class="form-field"><label>Agen Penanggung Jawab</label><div class="select-wrap-form"><select class="form-select" id="f-agen">
      ${karyawanList.map(k => `<option value="${esc(k.nama)}" ${t && t.agen === k.nama ? 'selected' : ''}>${esc(k.nama)}</option>`).join('')}
    </select><svg class="icon" data-lucide="chevron-down"></svg></div></div>
  `;
      const foot = `
    <button class="btn btn-ghost" id="modal-cancel">Batal</button>
    <button class="btn btn-blue" id="modal-save"><svg class="icon" style="width:14px;height:14px;" data-lucide="check"></svg>${editing ? 'Simpan Perubahan' : 'Buat Tiket'}</button>
  `;
      openModal(editing ? `Edit Tiket ${t.id}` : 'Buat Tiket Baru', body, foot);
      document.getElementById('modal-cancel').addEventListener('click', closeModal);
      document.getElementById('modal-save').addEventListener('click', () => {
        const judul = document.getElementById('f-judul').value.trim();
        if (!judul) { showToast('Judul tiket wajib diisi', 'triangle-alert'); return; }
        const data = {
          judul,
          deskripsi: document.getElementById('f-desc').value.trim() || '-',
          kontak: document.getElementById('f-kontak').value.trim() || 'Tanpa nama',
          telepon: document.getElementById('f-telepon').value.trim() || '-',
          prioritas: document.getElementById('f-prioritas').value,
          status: document.getElementById('f-status').value,
          tipe: document.getElementById('f-tipe').value,
          sumber: document.getElementById('f-sumber').value,
          agen: document.getElementById('f-agen').value || 'Belum ditentukan',
        };
        if (editing) {
          Object.assign(t, data); t.updated = nowStr();
          showToast(`Tiket ${t.id} berhasil diperbarui`, 'check');
          if (currentTicketId === t.id) renderTicketDetail(t.id);
        } else {
          const newId = '#' + (ticketSeq++);
          const ts = nowStr();
          tickets.unshift({ id: newId, ...data, dibuat: ts, updated: ts });
          showToast(`Tiket ${newId} berhasil dibuat`, 'sparkles');
        }
        renderTicketList(); renderDashboard();
        closeModal();
        setTimeout(() => { const r = document.querySelector(`[data-open="${editing ? t.id : tickets[0].id}"]`); if (r) r.classList.add('row-new'); }, 60);
      });
    }
    function confirmDeleteTicket(id, fromDetail) {
      const t = tickets.find(x => x.id === id);
      if (!t) return;
      openModal('Hapus Tiket', `
    <div class="confirm-icon"><svg class="icon" style="width:24px;height:24px;" data-lucide="trash-2"></svg></div>
    <p class="confirm-text">Yakin ingin menghapus tiket <b>${esc(t.id)} - ${esc(t.judul)}</b>? Tindakan ini tidak dapat dibatalkan.</p>
  `, `
    <button class="btn btn-ghost" id="modal-cancel">Batal</button>
    <button class="btn btn-danger" id="modal-confirm-del">Ya, Hapus</button>
  `, true);
      document.getElementById('modal-cancel').addEventListener('click', closeModal);
      document.getElementById('modal-confirm-del').addEventListener('click', () => {
        tickets = tickets.filter(x => x.id !== id);
        renderTicketList(); renderDashboard();
        closeModal();
        showToast(`Tiket ${id} berhasil dihapus`, 'trash-2');
        if (fromDetail) showPage('tiket-list');
      });
    }

    /* ============ DIVISI FORM ============ */
    function openDivisiForm(id) {
      const editing = id != null;
      const d = editing ? divisiList.find(x => x.id === id) : null;
      const body = `
    <div class="form-field"><label>Nama Divisi</label><input class="form-input" id="f-nama" value="${d ? esc(d.nama) : ''}" placeholder="Contoh: IT"></div>
    <div class="form-field"><label>Deskripsi</label><textarea class="form-textarea" id="f-desc" placeholder="Deskripsi singkat divisi">${d ? esc(d.desc) : ''}</textarea></div>
  `;
      const foot = `<button class="btn btn-ghost" id="modal-cancel">Batal</button><button class="btn btn-blue" id="modal-save"><svg class="icon" style="width:14px;height:14px;" data-lucide="check"></svg>${editing ? 'Simpan Perubahan' : 'Tambah Divisi'}</button>`;
      openModal(editing ? 'Edit Divisi' : 'Tambah Divisi', body, foot);
      document.getElementById('modal-cancel').addEventListener('click', closeModal);
      document.getElementById('modal-save').addEventListener('click', () => {
        const nama = document.getElementById('f-nama').value.trim();
        if (!nama) { showToast('Nama divisi wajib diisi', 'triangle-alert'); return; }
        const desc = document.getElementById('f-desc').value.trim() || '-';
        if (editing) { d.nama = nama; d.desc = desc; showToast('Divisi berhasil diperbarui', 'check'); }
        else { divisiList.push({ id: divisiSeq++, nama, desc }); showToast('Divisi berhasil ditambahkan', 'sparkles'); }
        renderDivisi(); renderKaryawan();
        closeModal();
      });
    }
    function confirmDeleteDivisi(id) {
      const d = divisiList.find(x => x.id === id);
      if (!d) return;
      const jml = karyawanList.filter(k => k.divisiId === id).length;
      openModal('Hapus Divisi', `
    <div class="confirm-icon"><svg class="icon" style="width:24px;height:24px;" data-lucide="trash-2"></svg></div>
    <p class="confirm-text">Yakin ingin menghapus divisi <b>${esc(d.nama)}</b>?${jml ? ` Terdapat <b>${jml} karyawan</b> yang terdaftar di divisi ini.` : ''}</p>
  `, `<button class="btn btn-ghost" id="modal-cancel">Batal</button><button class="btn btn-danger" id="modal-confirm-del">Ya, Hapus</button>`, true);
      document.getElementById('modal-cancel').addEventListener('click', closeModal);
      document.getElementById('modal-confirm-del').addEventListener('click', () => {
        divisiList = divisiList.filter(x => x.id !== id);
        renderDivisi(); renderKaryawan();
        closeModal();
        showToast('Divisi berhasil dihapus', 'trash-2');
      });
    }

    /* ============ KARYAWAN FORM ============ */
    function openKaryawanForm(id) {
      const editing = id != null;
      const k = editing ? karyawanList.find(x => x.id === id) : null;
      const body = `
    <div class="form-field"><label>Nama Lengkap</label><input class="form-input" id="f-nama" value="${k ? esc(k.nama) : ''}" placeholder="Nama karyawan"></div>
    <div class="form-field"><label>Email</label><input class="form-input" type="email" id="f-email" value="${k ? esc(k.email) : ''}" placeholder="nama@mitratani27.co.id"></div>
    <div class="form-row-2">
      <div class="form-field"><label>Divisi</label><div class="select-wrap-form"><select class="form-select" id="f-divisi">
        ${divisiList.map(d => `<option value="${d.id}" ${k && k.divisiId === d.id ? 'selected' : ''}>${esc(d.nama)}</option>`).join('')}
      </select><svg class="icon" data-lucide="chevron-down"></svg></div></div>
      <div class="form-field"><label>No. Telepon</label><input class="form-input" id="f-tlp" value="${k ? esc(k.tlp) : ''}" placeholder="08xx-xxxx-xxxx"></div>
    </div>
  `;
      const foot = `<button class="btn btn-ghost" id="modal-cancel">Batal</button><button class="btn btn-blue" id="modal-save"><svg class="icon" style="width:14px;height:14px;" data-lucide="check"></svg>${editing ? 'Simpan Perubahan' : 'Tambah Karyawan'}</button>`;
      openModal(editing ? 'Edit Karyawan' : 'Tambah Karyawan', body, foot);
      document.getElementById('modal-cancel').addEventListener('click', closeModal);
      document.getElementById('modal-save').addEventListener('click', () => {
        const nama = document.getElementById('f-nama').value.trim();
        const email = document.getElementById('f-email').value.trim();
        if (!nama || !email) { showToast('Nama dan email wajib diisi', 'triangle-alert'); return; }
        const data = { nama, email, divisiId: Number(document.getElementById('f-divisi').value), tlp: document.getElementById('f-tlp').value.trim() || '-' };
        if (editing) { Object.assign(k, data); showToast('Data karyawan berhasil diperbarui', 'check'); }
        else { karyawanList.push({ id: karyawanSeq++, ...data }); showToast('Karyawan berhasil ditambahkan', 'sparkles'); }
        renderKaryawan(); renderDivisi();
        closeModal();
      });
    }
    function confirmDeleteKaryawan(id) {
      const k = karyawanList.find(x => x.id === id);
      if (!k) return;
      openModal('Hapus Karyawan', `
    <div class="confirm-icon"><svg class="icon" style="width:24px;height:24px;" data-lucide="trash-2"></svg></div>
    <p class="confirm-text">Yakin ingin menghapus karyawan <b>${esc(k.nama)}</b> dari data perusahaan?</p>
  `, `<button class="btn btn-ghost" id="modal-cancel">Batal</button><button class="btn btn-danger" id="modal-confirm-del">Ya, Hapus</button>`, true);
      document.getElementById('modal-cancel').addEventListener('click', closeModal);
      document.getElementById('modal-confirm-del').addEventListener('click', () => {
        karyawanList = karyawanList.filter(x => x.id !== id);
        renderKaryawan(); renderDivisi();
        closeModal();
        showToast('Karyawan berhasil dihapus', 'trash-2');
      });
    }

    function openRolePermissions(id) {
      const r = rolesList.find(x=>x.id===id); if(!r) return;
      const body = `<p style="color:var(--text-mute);margin-top:0">Tentukan hak akses detail untuk <b>${esc(r.nama)}</b>. Centang sesuai kebutuhan. Daftar di bawah mengikuti struktur menu sidebar (<b>MENU</b> &amp; <b>LAINNYA</b>); setiap menu memiliki aksi <b>view / create / edit / delete</b> dan aksi khusus bila tersedia.</p><div class="permission-builder">${renderPermissionBuilder(r.permissions||[], 'perm')}</div>`;
      openModal('Hak Akses Role', body, `<button class="btn btn-ghost" id="modal-cancel">Batal</button><button class="btn btn-blue" id="modal-save"><svg class="icon" data-lucide="check"></svg>Simpan Hak Akses</button>`);
      document.querySelectorAll('[data-perm-all]').forEach(btn=>btn.addEventListener('click',()=>{ const resource=btn.dataset.permAll; document.querySelectorAll(`[data-perm^="${resource}."]`).forEach(x=>x.checked=true); }));
      document.getElementById('modal-cancel').addEventListener('click',closeModal);
      document.getElementById('modal-save').addEventListener('click',()=>{ r.permissions=[...document.querySelectorAll('[data-perm]:checked')].map(x=>x.dataset.perm); persistAdminState(); renderRoles(); if(currentUser?.roleId===r.id) applyPermissions(); closeModal(); showToast('Hak akses detail berhasil diperbarui','shield-check'); });
    }

    /* ============ ROLE FORM ============ */
    function openRoleForm(id) {
      const editing = id != null;
      const r = editing ? rolesList.find(x => x.id === id) : null;
      const existingPerms = normalizePermissions(r?.permissions || ['dashboard.view','tiket.view']);
      const body = `
    <div class="form-grid-2"><div class="form-field"><label>Nama Role</label><input class="form-input" id="f-nama" value="${r ? esc(r.nama) : ''}" placeholder="Contoh: Supervisor"></div>
    <div class="form-field"><label>Jumlah User Awal</label><input class="form-input" type="number" min="0" id="f-jml" value="${r ? r.jml : 0}"></div></div>
    <div class="permission-builder compact"><div class="permission-builder-title">Hak akses awal (mengikuti struktur menu sidebar)</div>${renderPermissionBuilder(existingPerms, 'newperm')}</div>
  `;
      const foot = `<button class="btn btn-ghost" id="modal-cancel">Batal</button><button class="btn btn-blue" id="modal-save"><svg class="icon" style="width:14px;height:14px;" data-lucide="check"></svg>${editing ? 'Simpan Perubahan' : 'Tambah Role'}</button>`;
      openModal(editing ? 'Edit Role' : 'Tambah Role', body, foot);
      document.querySelectorAll('[data-newperm-all]').forEach(btn=>btn.addEventListener('click',()=>{ const resource=btn.dataset.newpermAll; document.querySelectorAll(`[data-newperm^="${resource}."]`).forEach(x=>x.checked=true); }));
      document.getElementById('modal-cancel').addEventListener('click', closeModal);
      document.getElementById('modal-save').addEventListener('click', () => {
        const nama = document.getElementById('f-nama').value.trim();
        if (!nama) { showToast('Nama role wajib diisi', 'triangle-alert'); return; }
        const jml = Math.max(0, Number(document.getElementById('f-jml').value) || 0);
        const permissions=[...document.querySelectorAll('[data-newperm]:checked')].map(x=>x.dataset.newperm);
        if (editing) { r.nama = nama; r.jml = jml; r.permissions=permissions; showToast('Role berhasil diperbarui', 'check'); }
        else { rolesList.push({ id: roleSeq++, nama, jml, permissions }); showToast('Role berhasil ditambahkan', 'sparkles'); }
        persistAdminState();
        renderRoles();
        closeModal();
      });
    }
    function confirmDeleteRole(id) {
      const r = rolesList.find(x => x.id === id);
      if (!r) return;
      openModal('Hapus Role', `
    <div class="confirm-icon"><svg class="icon" style="width:24px;height:24px;" data-lucide="trash-2"></svg></div>
    <p class="confirm-text">Yakin ingin menghapus role <b>${esc(r.nama)}</b>?</p>
  `, `<button class="btn btn-ghost" id="modal-cancel">Batal</button><button class="btn btn-danger" id="modal-confirm-del">Ya, Hapus</button>`, true);
      document.getElementById('modal-cancel').addEventListener('click', closeModal);
      document.getElementById('modal-confirm-del').addEventListener('click', () => {
        rolesList = rolesList.filter(x => x.id !== id);
        persistAdminState();
        renderRoles();
        closeModal();
        showToast('Role berhasil dihapus', 'trash-2');
      });
    }

    function openUserForm(id) {
      const editing=id!=null, u=editing?usersList.find(x=>x.id===id):null;
      const roleOpts=rolesList.map(r=>`<option value="${r.id}" ${u?.roleId===r.id?'selected':''}>${esc(r.nama)}</option>`).join('');
      const divOpts='<option value="">Semua / Tidak ditentukan</option>'+divisiList.map(d=>`<option value="${d.id}" ${u?.divisiId===d.id?'selected':''}>${esc(d.nama)}</option>`).join('');
      const body=`<div class="form-grid-2"><div class="form-field"><label>Nama Lengkap</label><input class="form-input" id="u-nama" value="${u?esc(u.nama):''}"></div><div class="form-field"><label>Email Login</label><input class="form-input" type="email" id="u-email" value="${u?esc(u.email):''}"></div><div class="form-field"><label>Password</label><input class="form-input" type="password" id="u-pass" placeholder="${editing?'Kosongkan jika tidak diubah':'Minimal 6 karakter'}" value=""></div><div class="form-field"><label>Role</label><select class="form-input" id="u-role">${roleOpts}</select></div><div class="form-field"><label>Divisi</label><select class="form-input" id="u-divisi">${divOpts}</select></div><div class="form-field"><label>Status</label><select class="form-input" id="u-active"><option value="1" ${u?.active!==false?'selected':''}>Aktif</option><option value="0" ${u?.active===false?'selected':''}>Nonaktif</option></select></div></div>`;
      openModal(editing?'Edit Akun User':'Tambah Akun User',body,`<button class="btn btn-ghost" id="modal-cancel">Batal</button><button class="btn btn-blue" id="modal-save">Simpan Akun</button>`);
      document.getElementById('modal-cancel').addEventListener('click',closeModal);
      document.getElementById('modal-save').addEventListener('click',()=>{ const nama=document.getElementById('u-nama').value.trim(),email=document.getElementById('u-email').value.trim().toLowerCase(),pass=document.getElementById('u-pass').value,roleId=Number(document.getElementById('u-role').value),divisiId=Number(document.getElementById('u-divisi').value)||null,active=document.getElementById('u-active').value==='1'; if(!nama||!email||(!editing&&!pass)){showToast('Nama, email dan password wajib diisi','triangle-alert');return;} if(usersList.some(x=>x.email===email&&x.id!==id)){showToast('Email sudah digunakan','triangle-alert');return;} if(editing){u.nama=nama;u.email=email;u.roleId=roleId;u.divisiId=divisiId;u.active=active;if(pass)u.password=pass;}else usersList.push({id:userSeq++,nama,email,password:pass,roleId,divisiId,active}); persistAdminState(); renderUsers(); renderRoles(); closeModal(); showToast(editing?'Akun berhasil diperbarui':'Akun berhasil dibuat','user-check'); });
    }
    function confirmDeleteUser(id){ const u=usersList.find(x=>x.id===id); if(!u)return; openModal('Hapus Akun',`<div class="confirm-icon"><svg class="icon" data-lucide="trash-2"></svg></div><p class="confirm-text">Hapus akun <b>${esc(u.nama)}</b>?</p>`,`<button class="btn btn-ghost" id="modal-cancel">Batal</button><button class="btn btn-danger" id="modal-confirm-del">Ya, Hapus</button>`,true); document.getElementById('modal-cancel').addEventListener('click',closeModal); document.getElementById('modal-confirm-del').addEventListener('click',()=>{usersList=usersList.filter(x=>x.id!==id);persistAdminState();renderUsers();renderRoles();closeModal();showToast('Akun berhasil dihapus','trash-2');}); }
    function openContactProfile(name){ const u=usersList.find(x=>x.nama===name)||karyawanList.find(x=>x.nama===name); const count=tickets.filter(t=>t.kontak===name).length; const resolved=tickets.filter(t=>t.kontak===name&&t.status==='selesai').length; const email=u?.email||`${name.toLowerCase().replace(/\s+/g,'.')}@mitratani27.co.id`; const div=u?.divisiId?divisiName(u.divisiId):'—'; openModal('Profil Pengaju',`<div class="profile-modal"><div class="profile-avatar">${initials(name)}</div><h3>${esc(name)}</h3><p>${esc(email)}</p><div class="profile-stats"><div><strong>${count}</strong><span>Total tiket</span></div><div><strong>${resolved}</strong><span>Tiket selesai</span></div><div><strong>${count?Math.round((resolved/count)*100):0}%</strong><span>Penyelesaian</span></div></div><div class="profile-meta"><span>Divisi</span><b>${esc(div)}</b></div><div class="profile-meta"><span>Telepon</span><b>${esc(u?.tlp||'—')}</b></div></div>`,`<button class="btn btn-blue" id="modal-cancel">Tutup</button>`); document.getElementById('modal-cancel').addEventListener('click',closeModal); }
    function openCurrentUserProfile(){ if(!currentUser)return; openContactProfile(currentUser.nama); }
    function openSettingForm(key){
      const forms={
        company:`<div class="form-grid-2"><div class="form-field"><label>Nama Perusahaan</label><input class="form-input" id="s-name" value="${esc(settingsState.company.name)}"></div><div class="form-field"><label>Email</label><input class="form-input" id="s-email" value="${esc(settingsState.company.email)}"></div><div class="form-field"><label>Telepon</label><input class="form-input" id="s-phone" value="${esc(settingsState.company.phone)}"></div><div class="form-field"><label>Alamat</label><input class="form-input" id="s-address" value="${esc(settingsState.company.address)}"></div></div>`,
        email:`<div class="form-grid-2"><div class="form-field"><label>SMTP Host</label><input class="form-input" id="s-host" value="${esc(settingsState.email.host)}"></div><div class="form-field"><label>Port</label><input class="form-input" id="s-port" value="${esc(settingsState.email.port)}"></div><div class="form-field"><label>Email Pengirim</label><input class="form-input" id="s-sender" value="${esc(settingsState.email.sender)}"></div><label class="switch-row"><input type="checkbox" id="s-enabled" ${settingsState.email.enabled?'checked':''}><span>Aktifkan notifikasi email</span></label></div>`,
        categories:`<div class="form-field"><label>Kategori Tiket</label><textarea class="form-textarea" id="s-list">${settingsState.categories.join('\n')}</textarea><small>Satu kategori per baris.</small></div>`,
        statuses:`<div class="form-field"><label>Status Tiket</label><textarea class="form-textarea" id="s-list">${settingsState.statuses.join('\n')}</textarea><small>Urutan dari status awal sampai selesai.</small></div>`,
        backup:`<div class="backup-panel"><div><strong>Backup terakhir</strong><span>${esc(settingsState.backup.last)}</span></div><div><strong>Frekuensi</strong><select class="form-input" id="s-frequency"><option ${settingsState.backup.frequency==='Harian'?'selected':''}>Harian</option><option ${settingsState.backup.frequency==='Mingguan'?'selected':''}>Mingguan</option><option ${settingsState.backup.frequency==='Manual'?'selected':''}>Manual</option></select></div><button class="btn btn-blue" id="do-backup">Buat Backup Sekarang</button></div>`,
        general:`<div class="form-grid-2"><div class="form-field"><label>Zona Waktu</label><select class="form-input" id="s-tz"><option ${settingsState.general.timezone==='Asia/Jakarta'?'selected':''}>Asia/Jakarta</option><option>Asia/Makassar</option><option>Asia/Jayapura</option></select></div><div class="form-field"><label>Bahasa</label><select class="form-input" id="s-lang"><option>Bahasa Indonesia</option><option>English</option></select></div><label class="switch-row"><input type="checkbox" id="s-refresh" ${settingsState.general.autoRefresh?'checked':''}><span>Refresh dashboard otomatis</span></label></div>`};
      openModal(settingItems.find(x=>x.key===key)?.title||'Pengaturan',forms[key],`<button class="btn btn-ghost" id="modal-cancel">Batal</button><button class="btn btn-blue" id="modal-save">Simpan Pengaturan</button>`);
      document.getElementById('modal-cancel').addEventListener('click',closeModal);
      document.getElementById('do-backup')?.addEventListener('click',()=>{settingsState.backup.last=nowStr();persistAdminState();closeModal();showToast('Backup simulasi berhasil dibuat','database-backup');});
      document.getElementById('modal-save').addEventListener('click',()=>{ if(key==='company')settingsState.company={name:document.getElementById('s-name').value.trim(),email:document.getElementById('s-email').value.trim(),phone:document.getElementById('s-phone').value.trim(),address:document.getElementById('s-address').value.trim()}; if(key==='email')settingsState.email={host:document.getElementById('s-host').value.trim(),port:document.getElementById('s-port').value.trim(),sender:document.getElementById('s-sender').value.trim(),enabled:document.getElementById('s-enabled').checked}; if(key==='categories')settingsState.categories=document.getElementById('s-list').value.split('\n').map(x=>x.trim()).filter(Boolean); if(key==='statuses')settingsState.statuses=document.getElementById('s-list').value.split('\n').map(x=>x.trim()).filter(Boolean); if(key==='general')settingsState.general={timezone:document.getElementById('s-tz').value,language:document.getElementById('s-lang').value,autoRefresh:document.getElementById('s-refresh').checked}; persistAdminState();closeModal();showToast('Pengaturan berhasil disimpan','check');});
    }

    /* ============ COUNT UP ============ */
    function animateCounts(scope) {
      scope.querySelectorAll('.count-up').forEach(el => {
        const target = parseInt(el.dataset.target, 10) || 0;
        let t0 = null; const dur = 800;
        function step(t) {
          if (!t0) t0 = t;
          const p = Math.min((t - t0) / dur, 1);
          const eased = 1 - Math.pow(1 - p, 3);
          el.textContent = Math.round(eased * target);
          if (p < 1) requestAnimationFrame(step);
        }
        requestAnimationFrame(step);
      });
    }

    /* ============ CHARTS ============ */
    if (!window.Chart) {
      console.warn('Chart.js tidak tersedia. Grafik dilewati, fitur lain tetap aktif.');
    } else {
      Chart.defaults.font.family = "'Plus Jakarta Sans', sans-serif";
      Chart.defaults.color = '#7B9188';
    }
    let chartMonthly, chartStatus, chartPeriode, chartTipe;

    function renderCharts() {
      if (!window.Chart) return;
      const cm = document.getElementById('chartMonthly');
      if (chartMonthly) chartMonthly.destroy();
      const grad = cm.getContext('2d').createLinearGradient(0, 0, 0, 220);
      grad.addColorStop(0, 'rgba(46,72,229,.28)'); grad.addColorStop(1, 'rgba(46,72,229,0)');
      chartMonthly = new Chart(cm, {
        type: 'line',
        data: {
          labels: ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'],
          datasets: [{ data: [42, 58, 49, 70, 64, 88, 75, 66, 90, 80, 72, 95], borderColor: '#087F5B', backgroundColor: grad, fill: true, tension: .42, borderWidth: 2.5, pointRadius: 0, pointHoverRadius: 5, pointHoverBackgroundColor: '#087F5B', pointHoverBorderColor: '#fff', pointHoverBorderWidth: 2 }]
        },
        options: {
          responsive: true, maintainAspectRatio: false, animation: { duration: 900, easing: 'easeOutQuart' },
          plugins: { legend: { display: false }, tooltip: { backgroundColor: '#10221B', padding: 10, cornerRadius: 8, titleFont: { weight: 700 }, bodyFont: { weight: 600 } } },
          scales: {
            x: { grid: { display: false }, border: { display: false }, ticks: { font: { size: 11, weight: 600 } } },
            y: { grid: { color: '#EAF3EF' }, border: { display: false }, ticks: { font: { size: 11, weight: 600 }, stepSize: 50 } }
          }
        }
      });

      const cs = document.getElementById('chartStatus');
      if (chartStatus) chartStatus.destroy();
      const counts = { baru: 0, menunggu: 0, proses: 0, selesai: 0 };
      tickets.forEach(t => counts[t.status]++);
      chartStatus = new Chart(cs, {
        type: 'doughnut',
        data: { labels: ['Baru', 'Menunggu', 'Proses', 'Selesai'], datasets: [{ data: [counts.baru, counts.menunggu, counts.proses, counts.selesai], backgroundColor: ['#4E8F74', '#B7791F', '#C88917', '#12A36F'], borderWidth: 0, hoverOffset: 6 }] },
        options: {
          responsive: true, maintainAspectRatio: false, cutout: '72%', animation: { animateRotate: true, duration: 900 },
          plugins: { legend: { display: false }, tooltip: { backgroundColor: '#10221B', padding: 10, cornerRadius: 8 } }
        }
      });
    }

    function renderAnalyticsCharts() {
      if (!window.Chart) return;
      const cp = document.getElementById('chartPeriode');
      if (chartPeriode) chartPeriode.destroy();
      chartPeriode = new Chart(cp, {
        type: 'bar',
        data: {
          labels: ['1 Jan', '7 Jan', '13 Jan', '19 Jan', '21 Jan', '6 Feb', '13 Feb', '19 Feb', '24 Feb'],
          datasets: [
            { label: 'Baru', data: [12, 18, 10, 22, 15, 20, 14, 24, 17], backgroundColor: '#4E8F74', borderRadius: 4, barPercentage: .6 },
            { label: 'Proses', data: [8, 14, 12, 10, 18, 12, 16, 10, 14], backgroundColor: '#C88917', borderRadius: 4, barPercentage: .6 },
            { label: 'Selesai', data: [16, 10, 20, 14, 12, 22, 18, 20, 24], backgroundColor: '#12A36F', borderRadius: 4, barPercentage: .6 },
          ]
        },
        options: {
          responsive: true, maintainAspectRatio: false, animation: { duration: 900, easing: 'easeOutQuart' },
          plugins: { legend: { display: false }, tooltip: { backgroundColor: '#10221B', padding: 10, cornerRadius: 8 } },
          scales: {
            x: { stacked: false, grid: { display: false }, border: { display: false }, ticks: { font: { size: 10, weight: 600 } } },
            y: { grid: { color: '#EAF3EF' }, border: { display: false }, ticks: { font: { size: 11, weight: 600 } } }
          }
        }
      });

      const ct = document.getElementById('chartTipe');
      if (chartTipe) chartTipe.destroy();
      chartTipe = new Chart(ct, {
        type: 'doughnut',
        data: { labels: ['Incident', 'Request', 'Problem', 'Feature Request'], datasets: [{ data: [40, 30, 15, 15], backgroundColor: ['#087F5B', '#12A36F', '#C88917', '#4E8F74'], borderWidth: 0, hoverOffset: 6 }] },
        options: {
          responsive: true, maintainAspectRatio: false, cutout: '70%', animation: { animateRotate: true, duration: 900 },
          plugins: { legend: { display: false }, tooltip: { backgroundColor: '#10221B', padding: 10, cornerRadius: 8 } }
        }
      });
    }


  /* Global search: cari tiket/karyawan dari topbar */
  const globalSearch = document.querySelector('.search-box input');
  globalSearch?.addEventListener('keydown', e => {
    if (e.key !== 'Enter') return;
    const q = e.target.value.trim().toLowerCase();
    if (!q) return;
    const ticket = tickets.find(t => [t.id,t.judul,t.kontak,t.tipe].some(v => String(v).toLowerCase().includes(q)));
    if (ticket) {
      showPage('tiket-detail');
      renderTicketDetail(ticket.id);
      showToast(`Tiket ${ticket.id} ditemukan`, 'search');
      return;
    }
    const k = karyawanList.find(x => [x.nama,x.email,x.tlp].some(v => String(v).toLowerCase().includes(q)));
    if (k) {
      showPage('karyawan');
      document.getElementById('karyawan-search').value = e.target.value;
      renderKaryawan();
      showToast(`Karyawan ${k.nama} ditemukan`, 'search');
      return;
    }
    showToast('Data tidak ditemukan', 'triangle-alert');
  });

  /* Shortcut keyboard untuk terasa seperti aplikasi desktop */
  document.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
      e.preventDefault(); globalSearch?.focus(); globalSearch?.select();
    }
  });

  /* Refresh icon rendering after dynamic pages are inserted */
  lucide.createIcons();
}

initLoginFlow();
window.__helpdeskReady = bootHelpdesk().catch(err => {
  console.error('Helpdesk initialization failed:', err);
  return false;
});
