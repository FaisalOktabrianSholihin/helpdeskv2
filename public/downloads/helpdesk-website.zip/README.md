# Helpdesk Modern Green v6

Versi ini mempertahankan fitur front-end v5 dan memperbarui halaman **Cetak Tiket** agar mengikuti referensi pengguna: format A4 portrait, header tanggal/URL, identitas perusahaan + nomor tiket, Ticket Details, metadata pengajuan, deskripsi, dan komentar dengan garis pemisah dashed.

Tombol **Cetak / Simpan PDF** menggunakan dialog print browser dan CSS `@media print`, sehingga hasil cetak hanya menampilkan lembar tiket tanpa sidebar/topbar aplikasi.
